@echo off
chcp 65001 >nul
cd /d "%~dp0"
where python >nul 2>nul
if %errorlevel%==0 (
  python app.py
  goto :eof
)
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 app.py
  goto :eof
)
echo Python 3.8 or newer was not found.
echo Install Python from python.org, then run this file again.
pause
